import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { ApiProperty } from '@nestjs/swagger';
import { Document, model, Model } from 'mongoose';
import { IsNotEmpty, IsString, IsEmail } from 'class-validator';

@Schema({
  toJSON: { virtuals: true, getters: true },
  toObject: { virtuals: true, getters: true },
  timestamps: true,
})
export class User extends Document {
  @ApiProperty({
    description: 'The name of the customer. It should be a non-empty string.',
    type: String,
    minLength: 3,
  })
  @Prop({ type: String, required: true })
  @IsNotEmpty({ message: 'Name should not be empty' })
  @IsString({ message: 'Name must be a string' })
  name: string;

  @ApiProperty({
    description: 'The email address of the customer. It must be a valid email.',
    type: String,
  })
  @Prop({ type: String, required: false })
  @IsEmail({}, { message: 'Email must be a valid email address' })
  email: string;
}

export const UserSchema = SchemaFactory.createForClass(User);
export const UserModel: Model<User> = model<User>('User', UserSchema);
