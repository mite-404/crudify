import { Injectable } from '@nestjs/common';
import { User } from './entities/user.entity';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { ApiCoreService } from 'libs/api/api-core/src';
import { ApiConnectorMongoService } from 'libs/api/api-connector-mongo/src';

@Injectable()
export class UserService extends ApiConnectorMongoService<User> {
  constructor(@InjectModel(User.name) protected productModel: Model<User>) {
    super(productModel);
  }
  // async findAll(query: FilterQuery<any> = {}): Promise<any> {
  //   const results = await this.productModel.find().exec();
  //   return results;
  // }
}
