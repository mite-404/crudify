import { Controller, Get, UseGuards } from '@nestjs/common';
import { UserService } from './user.service';
import { User, UserSchema } from './entities/user.entity';
import { ApiOperation } from '@nestjs/swagger';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { ApiCoreController, Api } from '@forge-kit/api-core';
import { GatekeeperMongoService } from '@forge-kit/api-connector-mongo';
@Api({
  model: {
    type: User,
    cdto: CreateUserDto,
    udto: UpdateUserDto,
    schema: UserSchema,
  },
  softDelete: false,
  routes: {
    config: {
      findAll: {
        decorators: [
          // UseGuards(DisableRouteGuard),
          // ApiOperation({
          //   summary: '1111 usare più questo endpoint.',
          //   description:
          //     's endpoint sarà rimosso in futuro. Usa /example/new-endpoint invece.',
          // }),
        ],
        disabled: false,
      },
      // create: {
      //   decorators: [UseGuards(DisableRouteGuard)],
      // },
    },
    disableBulk: true,
    // decorators: [
    //   ApiOperation({
    //     summary: 'Nonnnnnnn usare più questo endpoint.',
    //     description:
    //       'ss endpoint sarà rimosso in futuro. Usa /example/new-endpoint invece.',
    //   }),
    // ],<
  },
})
@Controller('users')
export class UserController extends ApiCoreController<User> {
  constructor(private service: UserService) {
    super(service);
  }
}
