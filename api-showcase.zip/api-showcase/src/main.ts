import { Logger, ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app/app.module';

import { forgeBootstrap } from '@forge-kit/api-bootstrap';

forgeBootstrap(AppModule).catch((err) => {
  Logger.error(err);
  process.exit(1);
});
