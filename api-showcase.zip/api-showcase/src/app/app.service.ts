import { ApiConnectorMongoService } from 'libs/api/api-connector-mongo/src';
import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {}
