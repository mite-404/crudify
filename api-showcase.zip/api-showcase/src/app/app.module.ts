import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ApiCoreModule, GatekeeperService } from '@forge-kit/api-core';
import { ApiConnectorMongoModule, GatekeeperMongoService } from '@forge-kit/api-connector-mongo';
import { MongooseModule } from '@nestjs/mongoose';
import { UserModule } from '../user/user.module';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { GatekeeperMongoModule } from '@forge-kit/api-connector-mongo';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        uri: configService.get<string>('DB_URI', 'mongodb://127.0.0.1:27017/'),
      }),
      inject: [ConfigService],
    }),
    ApiCoreModule,
    ApiConnectorMongoModule,
    UserModule
  ],
  controllers: [AppController],
  providers: [AppService,
    {
      provide: GatekeeperService, // Il token astratto della libreria
      useExisting: GatekeeperMongoService, // La tua implementazione specifica
    }

  ]
})
export class AppModule { }