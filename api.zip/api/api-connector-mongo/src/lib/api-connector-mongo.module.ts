import { Module } from '@nestjs/common';
import { ApiConnectorMongoService } from './api-connector-mongo.service';
import { GatekeeperMongoModule } from '../gatekeeper/gatekeeper.module';

@Module({
  imports: [GatekeeperMongoModule],
  providers: [],
  exports: [],
})
export class ApiConnectorMongoModule { }
