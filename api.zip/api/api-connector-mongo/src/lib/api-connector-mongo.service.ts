import { Injectable } from '@nestjs/common';
import { Model, UpdateQuery } from 'mongoose';
import { QueryParser } from './utils/query-parser';
import { ApiCoreService } from '@forge-kit/api-core';

/**
 * MongoDB implementation of the ApiCoreService.
 * 
 * This service provides a complete implementation of all CRUD operations
 * using Mongoose models. It includes support for:
 * - Single and bulk create/update/delete operations
 * - Advanced query parsing with filtering, sorting, and pagination
 * - Soft delete and restore functionality
 * - Population of related documents
 * 
 * @template T The Mongoose document type
 * @template C The create DTO type (defaults to Partial<T>)
 * @template U The update DTO type (defaults to Partial<T>)
 * 
 * @example
 * ```typescript
 * @Injectable()
 * export class UserService extends ApiConnectorMongoService<User> {
 *   constructor(@InjectModel(User.name) userModel: Model<User>) {
 *     super(userModel);
 *   }
 * }
 * ```
 */
@Injectable()
export class ApiConnectorMongoService<
  T,
  C = Partial<T>,
  U = Partial<T>
> extends ApiCoreService<T, C, U> {
  /**
   * Creates a new instance of the MongoDB service.
   * 
   * @param model - The Mongoose model to use for database operations
   */
  constructor(protected readonly model: Model<T>) {
    super();
  }

  async create(createDto: C): Promise<T | any> {
    const entity = new this.model(createDto);
    return entity.save();
  }

  async createBulk(data: C[]): Promise<T[] | any> {
    return this.model.insertMany(data);
  }

  async findAll(
    query: any = {}
  ): Promise<{ results: T[]; total: number; page: number }> {
    const { filters, populate, sort, skip, limit } = QueryParser.parse(query);
    const results = await this.model
      .find(filters)
      .populate(populate)
      .sort(sort)
      .skip(skip)
      .limit(limit)
      .exec();

    const total = await this.model.countDocuments(filters).exec();

    return { results, total, page: Math.ceil(skip / limit) };
  }

  async findOne(filter: any): Promise<T | null> {
    return this.model.findOne(filter).exec();
  }

  async count(filter: Record<string, any>): Promise<number> {
    return this.model.countDocuments(filter).exec();
  }

  async put(id: string, updateDto: UpdateQuery<U>): Promise<T | null> {
    return this.model
      .findOneAndReplace({ _id: id }, updateDto, { new: true })
      .exec();
  }

  async update(id: string, updateDto: UpdateQuery<T>): Promise<T | null> {
    return this.model
      .findOneAndUpdate({ _id: id }, updateDto, { new: true })
      .exec();
  }

  async updateBulk(filter: any, updateDto: UpdateQuery<U>): Promise<any> {
    return this.model.updateMany(filter, { $set: updateDto }).exec();
  }

  async delete(id: string): Promise<T | null> {
    return this.model.findByIdAndDelete(id).exec();
  }

  async deleteBulk(filter: any): Promise<any> {
    return this.model.deleteMany(filter).exec();
  }

  async softDelete(id: string): Promise<T | null> {
    return this.model
      .findOneAndUpdate(
        { _id: id },
        { deletedAt: new Date() },
        { new: true, strict: false }
      )
      .exec();
  }

  async softDeleteBulk(filter: any): Promise<any> {
    return this.model
      .updateMany(
        filter,
        { $set: { deletedAt: new Date() } },
        { strict: false }
      )
      .exec();
  }

  async restore(id: string): Promise<T | null> {
    return this.model
      .findByIdAndUpdate(
        id,
        { $unset: { deletedAt: null } },
        { new: true, strict: false }
      )
      .exec();
  }

  async restoreBulk(filter: any): Promise<any> {
    return this.model
      .updateMany(filter, { $unset: { deletedAt: null } }, { strict: false })
      .exec();
  }
}
