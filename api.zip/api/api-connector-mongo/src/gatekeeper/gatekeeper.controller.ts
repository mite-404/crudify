import { GatekeeperController } from '@forge-kit/api-core';
import { GatekeeperMongoService } from './gatekeeper.service';

export class GatekeeperMongoController extends GatekeeperController {
  constructor(protected override readonly configService: GatekeeperMongoService) {
    super(configService);
  }
}
