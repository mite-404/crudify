import { Global, Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Gatekeeper, GatekeeperSchema } from './gatekeeper.entity';
import { GatekeeperMongoService } from './gatekeeper.service';
import { GatekeeperMongoController } from './gatekeeper.controller';
import { GatekeeperService } from '@forge-kit/api-core';

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([{ name: Gatekeeper.name, schema: GatekeeperSchema }]),
  ],
  controllers: [GatekeeperMongoController],
  providers: [
    GatekeeperMongoService,
    {
      provide: GatekeeperService,
      useExisting: GatekeeperMongoService,
    },
  ],
  exports: [GatekeeperMongoService, GatekeeperService],
})
export class GatekeeperMongoModule { }
