import { Injectable } from '@nestjs/common';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { Gatekeeper } from './gatekeeper.entity';
import { GatekeeperService } from '@forge-kit/api-core';

/**
 * MongoDB implementation of the GatekeeperService.
 * This service handles the persistence of route configurations in a MongoDB collection
 * and manages the transformation of database documents into the in-memory cache.
 * * @extends {GatekeeperService}
 */
@Injectable()
export class GatekeeperMongoService extends GatekeeperService {
  /**
   * Creates an instance of GatekeeperMongoService.
   * * @param {Model<Gatekeeper>} gatekeeperModel - The Mongoose model for the Gatekeeper collection.
   */
  constructor(@InjectModel(Gatekeeper.name) private gatekeeperModel: Model<Gatekeeper>) {
    super();
  }

  /**
   * Fetches all configuration records from MongoDB and populates the local cache.
   * Maps the database documents to a key-value structure where the key is the model name.
   * * @override
   * @returns {Promise<void>}
   */
  override async load(): Promise<void> {
    const configs = await this.gatekeeperModel.find().exec();
    this.configCache = configs.reduce((acc: any, cfg: any) => {
      acc[cfg.modelName] = {
        enabled: cfg.enabled,
        routes: cfg.routes,
      };
      return acc;
    }, {});
  }

  /**
   * Updates or creates (upserts) the configuration for a specific model in MongoDB.
   * * @override
   * @param {string} model - The name of the model to update.
   * @param {Partial<Gatekeeper>} updates - The configuration changes to persist.
   * @returns {Promise<void>}
   */
  override async updateConfig(
    model: string,
    updates: Partial<Gatekeeper>
  ): Promise<void> {
    await this.gatekeeperModel.updateOne({ modelName: model }, updates, {
      upsert: true,
    });
  }
}