import { Logger, Type, ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';

import { ConfigService } from '@nestjs/config';
import { initDocs } from './../bootstrap/init-docs';
import { initErrsole } from './../bootstrap/init-errsole';
import { logStartup } from './../bootstrap/log-startup';

/**
 * Standardized bootstrap function for Forge applications.
 * Handles NestJS initialization, global configurations, and third-party integrations.
 * * @param AppModule - The root module of the application to bootstrap.
 */
export async function forgeBootstrap(AppModule: Type<any>,) {
  const app = await NestFactory.create(AppModule);

  app.useGlobalPipes(new ValidationPipe());

  const globalPrefix = 'api';
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
  app.setGlobalPrefix(globalPrefix);

  const configService = app.get(ConfigService);
  const port = configService.get<number>('PORT', 3000);
  const dbUri = configService.get<string>('DB_URI') || 'mongodb://127.0.0.1:27017/';

  initDocs(app);
  initErrsole({ appName: 'forge', dbUri });
  await app.listen(port);

  logStartup({ port, globalPrefix, dbUri });
}
