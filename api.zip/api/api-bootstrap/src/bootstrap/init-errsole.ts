import ErrsoleMongoDB from 'errsole-mongodb';
// import errsole from 'errsole';
// import * as errsole from 'errsole';
import errsole = require('errsole');

export function initErrsole({
  appName,
  dbUri
}: {
  appName: string;
  dbUri: string;
}) {
  errsole.initialize({
    storage: new ErrsoleMongoDB(dbUri, //TODO: parametrizzare mongo
      { appName }
    ),
    collectLogs: ['error', 'info'],
    enableConsoleOutput: true,
    enableDashboard: true,
    path: '/logs',
    appName,
  });
}
