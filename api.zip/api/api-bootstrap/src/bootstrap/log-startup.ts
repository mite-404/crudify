export function logStartup({
  port,
  dbUri,
  globalPrefix,
}: {
  port: number | string;
  dbUri: string;
  globalPrefix: string;
}) {
  const base = `http://localhost:${port}`;

  const bright = (t: string) => `\x1b[97m${t}\x1b[0m`;
  const grey = (t: string) => `\x1b[90m${t}\x1b[0m`;
  const border = (t: string) => `\x1b[90m${t}\x1b[0m`;
  const cyan = (t: string) => `\x1b[36m${t}\x1b[0m`;
  console.log('');
  console.log(border('──────────────────────────────────────────────'));
  console.log(bright(' ForgeLab API Ready'));
  console.log(border('──────────────────────────────────────────────'));

  console.log(`${grey(' API:        ')} ${cyan(`${base}/${globalPrefix}`)}`);
  console.log(`${grey(' Scalar:     ')} ${cyan(`${base}/scalar`)}`);
  console.log(`${grey(' Errsole:    ')} ${cyan('http://localhost:8001/logs')}`);
  console.log(
    `${grey(' MongoDB:    ')} ${cyan(dbUri)}`
  );

  console.log(border('──────────────────────────────────────────────'));
  console.log('');
}
