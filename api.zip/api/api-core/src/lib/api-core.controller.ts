import {
  Body,
  Controller,
  Delete,
  Get,
  Inject,
  Param,
  Patch,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiCoreService } from './api-core.service';
import { GatekeeperService } from '../gatekeeper/gatekeeper.service';

/**
 * Base controller providing standard REST API endpoints for CRUD operations.
 * 
 * This controller implements all standard CRUD endpoints with support for:
 * - Single and bulk operations
 * - Soft delete functionality
 * - Dynamic route enabling/disabling via ConfigService
 * - Automatic metadata-based configuration
 * 
 * @template T The entity type that this controller manages
 * @template C The create DTO type (defaults to Partial<T>)
 * @template U The update DTO type (defaults to Partial<T>)
 * 
 * @example
 * ```typescript
 * @Controller('users')
 * export class UserController extends ApiCoreController<User, CreateUserDto, UpdateUserDto> {
 *   constructor(
 *     userService: UserService,
 *     configService?: ConfigService
 *   ) {
 *     super(userService, configService);
 *   }
 * }
 * ```
 */
@Controller(':entity')
export class ApiCoreController<T, C = Partial<T>, U = Partial<T>> {
  @Inject(GatekeeperService)
  protected readonly configService?: GatekeeperService;

  constructor(
    protected readonly apiCoreService: ApiCoreService<T, C, U>
  ) { }

  softDelete = Reflect.getMetadata('softDelete', this);
  modelName = Reflect.getMetadata('modelName', this);
  @Post()
  create(@Body() createDto: C) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'create') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(this.modelName, 'create');
    return this.apiCoreService.create(createDto);
  }

  @Post('bulk')
  createBulk(@Body() data: C[]) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'createBulk') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(
        this.modelName,
        'createBulk'
      );
    return this.apiCoreService.createBulk(data);
  }

  @Get()
  findAll(@Query() query: any) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'findAll') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(this.modelName, 'findAll');
    return this.apiCoreService.findAll(query);
  }

  @Get('count')
  count(@Query() query: any) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'count') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(this.modelName, 'count');
    return this.apiCoreService.count(query);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    console.log(this.modelName);
    console.log(this.configService)
    console.log(this.configService?.isRouteEnabled(this.modelName, 'findOne'))
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'findOne') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(this.modelName, 'findOne');
    return this.apiCoreService.findOne({ _id: id });
  }

  @Put(':id')
  put(@Param('id') id: string, @Body() updateDto: Partial<U>) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'put') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(this.modelName, 'put');
    return this.apiCoreService.put(id, updateDto);
  }

  @Patch('bulk')
  async updateBulk(@Body() body: { filter: any; updateDto: any }) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'updateBulk') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(
        this.modelName,
        'updateBulk'
      );
    const { filter, updateDto } = body;
    return this.apiCoreService.updateBulk(filter, updateDto);
  }

  @Patch('bulk/restore')
  async restoreBulk(@Body() body: { filter: any }) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'restoreBulk') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(
        this.modelName,
        'restoreBulk'
      );
    const { filter } = body;
    return this.apiCoreService.restoreBulk(filter);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateDto: Partial<T>) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'update') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(this.modelName, 'update');
    return this.apiCoreService.update(id, updateDto);
  }

  @Delete('bulk')
  async deleteBulk(@Body() body: { filter: any }) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'deleteBulk') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(
        this.modelName,
        'deleteBulk'
      );
    const { filter } = body;
    if (this.softDelete) return this.apiCoreService.softDeleteBulk(filter);
    return this.apiCoreService.deleteBulk(filter);
  }

  @Delete(':id')
  delete(@Param('id') id: string) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'delete') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(this.modelName, 'delete');
    if (this.softDelete) return this.apiCoreService.softDelete(id);
    return this.apiCoreService.delete(id);
  }

  @Delete(':id/soft')
  deleteSoft(@Param('id') id: string) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'deleteSoft') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(
        this.modelName,
        'deleteSoft'
      );
    return this.apiCoreService.softDelete(id);
  }

  @Delete(':id/restore')
  restore(@Param('id') id: string) {
    const isEnabled =
      this.configService?.isRouteEnabled(this.modelName, 'restore') ?? true;
    if (!isEnabled)
      return this.configService?.notEnabledResponse(this.modelName, 'restore');
    return this.apiCoreService.restore(id);
  }
}
