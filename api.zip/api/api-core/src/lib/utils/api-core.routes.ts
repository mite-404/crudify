import {
  Body,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiCore } from '../interfaces/api-core.interface';
import { Methods } from '../types/methods.type';
import { ApiCoreRoutesDecorator } from '../decoratos/api-core-routes.decorator';

/**
 * Namespace containing route configuration utilities for the API Core framework.
 * 
 * Provides functions to generate route configurations for all CRUD operations,
 * including HTTP methods, paths, parameters, and decorators.
 */
export namespace ApiCoreRoutes {
  /**
   * Generates an array of route configurations for all CRUD operations.
   * 
   * Creates route definitions for create, read, update, delete operations
   * including both single and bulk variants, as well as soft delete and restore.
   * 
   * @param options - The ApiCore configuration object
   * @returns An array of route configuration objects
   */
  export function routes(options: ApiCore) {
    return [
      RouteFindAll(options),
      RouteCount(options),
      RouteRestore(options),
      RouteFindOne(options),
      RouteCreate(options),
      RouteCreateBulk(options),
      RoutePatchBulk(options),
      RouteRestoreBulk(options),
      RoutePatch(options),
      RoutePut(options),
      RouteDeleteBulk(options),
      RouteDelete(options),
      RouteDeleteSoft(options),
    ];
  }

  function RouteFindAll(options: ApiCore) {
    const methodName: Methods = 'findAll';
    return {
      methodName,
      httpMethod: Get,
      path: '/',
      parameters: [{ index: 0, decorator: Query(), type: Object }],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RouteCount(options: ApiCore) {
    const methodName: Methods = 'count';
    return {
      methodName,
      httpMethod: Get,
      path: '/count',
      parameters: [],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RouteFindOne(options: ApiCore) {
    const methodName: Methods = 'findOne';
    const name: string = options.model.type.name.toLowerCase();
    return {
      methodName,
      httpMethod: Get,
      path: '/:id',
      parameters: [
        {
          index: 0,
          decorator: Param('id'),
          type: String,
          description: `ID of the ${name} resource`,
        },
      ],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RouteCreate(options: ApiCore) {
    const methodName: Methods = 'create';
    const name: string = options.model.type.name.toLowerCase();
    return {
      methodName,
      httpMethod: Post,
      path: '/',
      parameters: [
        {
          index: 0,
          decorator: Body(),
          type: options.model.cdto || options.model.type,
        },
      ],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RouteCreateBulk(options: ApiCore) {
    const methodName: Methods = 'createBulk';
    const name: string = options.model.type.name.toLowerCase();
    return {
      methodName,
      httpMethod: Post,
      path: '/bulk',
      parameters: [
        {
          index: 0,
          decorator: Body(),
          type: [options.model.cdto || options.model.type],
          description: `Array of ${name} resources to create`,
        },
      ],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RoutePatch(options: ApiCore) {
    const methodName: Methods = 'update';
    const name: string = options.model.type.name.toLowerCase();
    return {
      methodName,
      httpMethod: Patch,
      path: '/:id',
      parameters: [
        {
          index: 0,
          decorator: Param('id'),
          type: String,
          description: `ID of the ${name} resource`,
        },
        {
          index: 1,
          decorator: Body(),
          type: options.model.udto || options.model.type,
        },
      ],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RoutePatchBulk(options: ApiCore) {
    const methodName: Methods = 'updateBulk';
    const name: string = options.model.type.name.toLowerCase();
    return {
      methodName,
      httpMethod: Patch,
      path: '/bulk',
      parameters: [
        {
          index: 0,
          decorator: Body(),
          type: Object,
          description: `Object containing filter and data to update multiple ${name} resources`,
        },
      ],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RoutePut(options: ApiCore) {
    const methodName: Methods = 'put';
    const name: string = options.model.type.name.toLowerCase();
    return {
      methodName,
      httpMethod: Put,
      path: '/:id',
      parameters: [
        {
          index: 0,
          decorator: Param('id'),
          type: String,
          description: `ID of the ${name} resource`,
        },
        {
          index: 1,
          decorator: Body(),
          type: options.model.udto || options.model.type,
        },
      ],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RouteDelete(options: ApiCore) {
    const methodName: Methods = 'delete';
    const name: string = options.model.type.name.toLowerCase();
    return {
      methodName,
      httpMethod: Delete,
      path: '/:id',
      parameters: [
        {
          index: 0,
          decorator: Param('id'),
          type: String,
          description: `ID of the ${name} resource`,
        },
      ],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RouteDeleteBulk(options: ApiCore) {
    const methodName: Methods = 'deleteBulk';
    const name: string = options.model.type.name.toLowerCase();
    return {
      methodName,
      httpMethod: Delete,
      path: '/bulk',
      parameters: [
        {
          index: 0,
          decorator: Body(),
          type: Object,
          description: `Object containing filter and data to delete multiple ${name} resources`,
        },
      ],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RouteDeleteSoft(options: ApiCore) {
    const methodName: Methods = 'deleteSoft';
    const name: string = options.model.type.name.toLowerCase();
    return {
      methodName,
      httpMethod: Delete,
      path: '/:id/soft',
      parameters: [
        {
          index: 0,
          decorator: Param('id'),
          type: String,
          description: `ID of the ${name} resource`,
        },
      ],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RouteRestore(options: ApiCore) {
    const methodName: Methods = 'restore';
    const name: string = options.model.type.name.toLowerCase();
    return {
      methodName,
      httpMethod: Delete,
      path: '/:id/restore',
      parameters: [
        {
          index: 0,
          decorator: Param('id'),
          type: String,
          description: `ID of the ${name} resource`,
        },
      ],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }

  function RouteRestoreBulk(options: ApiCore) {
    const methodName: Methods = 'restoreBulk';
    const name: string = options.model.type.name.toLowerCase();
    return {
      methodName,
      httpMethod: Patch,
      path: '/bulk/restore',
      parameters: [
        {
          index: 0,
          decorator: Body(),
          type: Object,
          description: `Object containing filter to restore multiple ${name} resources`,
        },
      ],
      decorators: ApiCoreRoutesDecorator.getDecorators(options, methodName),
    };
  }
}
