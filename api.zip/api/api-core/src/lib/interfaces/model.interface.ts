import { Type } from '@nestjs/common';
// import { Schema } from 'mongoose';

/**
 * Configuration for an API resource model.
 * 
 * Defines the entity type and optional DTOs for create and update operations.
 */
export interface ApiCoreModel {
  /**
   * The entity class type that this model represents.
   */
  type: Type;

  /**
   * Optional Create Data Transfer Object type.
   * If not provided, Partial<T> will be used.
   */
  cdto?: Type;

  /**
   * Optional Update Data Transfer Object type.
   * If not provided, Partial<T> will be used.
   */
  udto?: Type;

  /**
   * Optional database schema definition.
   * Used by database connectors (e.g., Mongoose schema).
   */
  schema?: any;
}
