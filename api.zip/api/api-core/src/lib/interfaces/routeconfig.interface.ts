/**
 * Configuration for an individual API route.
 * 
 * Allows applying custom decorators or disabling specific routes.
 */
export type RouteConfig = {
  /**
   * Custom decorators to apply to this specific route.
   * These are applied in addition to any global decorators.
   */
  decorators?: MethodDecorator[];

  /**
   * Disable this specific route.
   * When true, the route will not be generated.
   * @default false
   */
  disabled?: boolean;
};
