import { ApiCoreModel } from './model.interface';
import { ApiRoutes } from './routes.interface';

/**
 * Configuration interface for defining API core functionality.
 * 
 * This interface is used to configure API endpoints with their associated models,
 * routes, and soft delete capabilities.
 */
export interface ApiCore {
  /**
   * The model configuration including entity type and DTOs.
   */
  model: ApiCoreModel;

  /**
   * Optional route configuration for customizing API endpoints.
   */
  routes?: ApiRoutes;

  /**
   * Enable soft delete functionality for this API resource.
   * When true, delete operations will mark records as deleted instead of removing them.
   * @default false
   */
  softDelete?: boolean;
}
