import { Methods } from '../types/methods.type';
import { RouteConfig } from './routeconfig.interface';

/**
 * Configuration for customizing API routes.
 * 
 * Allows fine-grained control over which routes are exposed and how they behave.
 */
export interface ApiRoutes {
  /**
   * Per-method route configuration.
   * Allows customizing individual CRUD operations with decorators or disabling them.
   */
  config?: Partial<Record<Methods, RouteConfig>>;

  /**
   * Array of method names to exclude from the API.
   * Excluded methods will not have routes generated.
   */
  exclude?: Methods[];

  /**
   * Global decorators to apply to all routes.
   * These decorators will be applied to every generated endpoint.
   */
  decorators?: MethodDecorator[];

  /**
   * Disable bulk operations (createBulk, updateBulk, deleteBulk, restoreBulk).
   * @default false
   */
  disableBulk?: boolean;
}
