import { Injectable, CanActivate, ExecutionContext } from "@nestjs/common";

/**
 * Guard that prevents access to disabled API routes.
 * 
 * This guard is automatically applied to routes that have been excluded
 * via the ApiCore configuration. It always returns false, effectively
 * blocking all requests to the protected route.
 */
@Injectable()
export class DisableRouteGuard implements CanActivate {
  /**
   * Always returns false to deny access to the route.
   * 
   * @param context - The execution context of the request
   * @returns Always false to block access
   */
  canActivate(context: ExecutionContext): boolean {
    // const request = context.switchToHttp().getRequest();
    // const handlerName = context.getHandler().name;
    return false;
  }
}
