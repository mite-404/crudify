import { Module } from '@nestjs/common';

/**
 * Main module for the API Core framework.
 * 
 * This module provides the core infrastructure for building REST APIs
 * with standardized CRUD operations, decorators, and utilities.
 */
@Module({
  controllers: [],
  providers: [],
  exports: [],
})
export class ApiCoreModule {}
