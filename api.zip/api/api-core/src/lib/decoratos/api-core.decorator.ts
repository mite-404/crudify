import { applyDecorators } from '@nestjs/common';
import 'reflect-metadata';
import { ApiCore } from '../interfaces/api-core.interface';
import { ApiCoreRoutes } from '../utils/api-core.routes';

/**
 * Class decorator that automatically generates REST API routes for a controller.
 * 
 * This decorator configures a NestJS controller to expose standard CRUD endpoints
 * based on the provided ApiCore configuration. It handles route generation, parameter
 * binding, Swagger documentation, and soft delete functionality.
 * 
 * @template T The entity type that the API manages
 * @param options - Configuration object defining the model, routes, and behavior
 * 
 * @example
 * ```typescript
 * @Api({
 *   model: {
 *     type: User,
 *     cdto: CreateUserDto,
 *     udto: UpdateUserDto
 *   },
 *   softDelete: true,
 *   routes: {
 *     exclude: ['deleteBulk'],
 *     disableBulk: false
 *   }
 * })
 * @Controller('users')
 * export class UserController extends ApiCoreController<User> {
 *   constructor(private readonly userService: UserService) {
 *     super(userService);
 *   }
 * }
 * ```
 */
export function Api<T>(options: ApiCore) {
  return function (target: Function) {
    const prototype = target.prototype;
    const basePrototype = Object.getPrototypeOf(prototype);
    const isSoftDelete = options.softDelete ?? false;
    Reflect.defineMetadata('model', options.model, prototype);
    Reflect.defineMetadata('modelName', options.model.type.name, prototype);

    disableRoutes(options, prototype, isSoftDelete);
    const routes = ApiCoreRoutes.routes(options);
    for (const route of routes) {
      let method = prototype[route.methodName];

      if (!method || method === basePrototype[route.methodName]) {
        method = function (this: any, ...args: any[]) {
          return basePrototype[route.methodName]?.apply(this, args);
        };

        Object.defineProperty(prototype, route.methodName, {
          value: method,
          writable: true,
          configurable: true,
        });
      }

      if (isSoftDelete && route.methodName === 'delete') {
        const originalMethod = prototype[route.methodName];
        prototype[route.methodName] = async function (...args: any[]) {
          const entity = args[0];
          const deleteDto = { deletedAt: new Date() };
          return originalMethod.apply(this, [entity, deleteDto]);
        };
      }

      if (route.parameters) {
        for (const param of route.parameters) {
          param.decorator(prototype, route.methodName, param.index);
        }
      }

      const uniqueOperationId = `${target.name}_${route.methodName}`;

      Reflect.defineMetadata(
        'swagger/apiOperation',
        {
          operationId: uniqueOperationId,
          summary: `Method: ${route.methodName}`,
        },
        prototype,
        route.methodName
      );

      const methodDecorators = [
        route.httpMethod(route.path),
        ...route.decorators,
      ];

      applyDecorators(...methodDecorators)(
        prototype,
        route.methodName,
        Object.getOwnPropertyDescriptor(prototype, route.methodName)!
      );
    }
  };
}

/**
 * Configures route exclusions and soft delete metadata for an API controller.
 * 
 * This helper function processes the ApiCore options to determine which routes
 * should be disabled, including handling bulk operation exclusions when configured.
 * 
 * @param options - The ApiCore configuration object
 * @param prototype - The controller prototype to attach metadata to
 * @param isSoftDelete - Whether soft delete is enabled for this controller
 */
export function disableRoutes(
  options: ApiCore,
  prototype: any,
  isSoftDelete: boolean
) {
  Reflect.defineMetadata('softDelete', isSoftDelete, prototype);
  if (options.routes === undefined) options.routes = { exclude: [] };
  if (options.routes?.exclude === undefined) {
    options.routes.exclude = [];
  }

  if (Array.isArray(options.routes.exclude)) {
    // if (!isSoftDelete) {
    //   options.routes.exclude.push("restore");
    //   options.routes.exclude.push("restoreBulk");
    // }
    if (options.routes?.disableBulk) {
      options.routes.exclude.push('createBulk');
      options.routes.exclude.push('updateBulk');
      options.routes.exclude.push('deleteBulk');
      options.routes.exclude.push('restoreBulk');
    }
  }
}
