import { Injectable } from '@nestjs/common';

/**
 * Abstract base service providing standard CRUD operations for API resources.
 * 
 * This service defines the contract for all API services in the Forge Kit framework,
 * providing a consistent interface for data manipulation operations including
 * create, read, update, delete, and bulk operations.
 * 
 * @template T The entity type that this service manages
 * @template C The create DTO type (defaults to Partial<T>)
 * @template U The update DTO type (defaults to Partial<T>)
 * 
 * @example
 * ```typescript
 * class UserService extends ApiCoreService<User, CreateUserDto, UpdateUserDto> {
 *   // Implement abstract methods
 * }
 * ```
 */
@Injectable()
export abstract class ApiCoreService<T, C = Partial<T>, U = Partial<T>> {
  /**
   * Creates a new entity.
   * 
   * @param createDto - The data transfer object containing the entity data to create
   * @returns A promise that resolves to the created entity
   */
  abstract create(createDto: C): Promise<T | any>;

  /**
   * Creates multiple entities in a single operation.
   * 
   * @param data - An array of create DTOs
   * @returns A promise that resolves to an array of created entities
   */
  abstract createBulk(data: C[]): Promise<T[] | any>;

  /**
   * Retrieves all entities matching the provided query with pagination support.
   * 
   * @param query - Query parameters for filtering, sorting, and pagination
   * @returns A promise that resolves to an object containing results, total count, and current page
   */
  abstract findAll(
    query: any
  ): Promise<{ results: T[]; total: number; page: number }>;

  /**
   * Finds a single entity matching the provided filter.
   * 
   * @param filter - The filter criteria to match
   * @returns A promise that resolves to the found entity or null if not found
   */
  abstract findOne(filter: any): Promise<T | null>;

  /**
   * Counts the number of entities matching the provided filter.
   * 
   * @param filter - The filter criteria to match
   * @returns A promise that resolves to the count of matching entities
   */
  abstract count(filter: Record<string, any>): Promise<number>;

  /**
   * Replaces an entire entity with new data (PUT operation).
   * 
   * @param id - The unique identifier of the entity to replace
   * @param updateDto - The complete replacement data
   * @returns A promise that resolves to the replaced entity or null if not found
   */
  abstract put(id: string, updateDto: any): Promise<T | null>;

  /**
   * Partially updates an entity (PATCH operation).
   * 
   * @param id - The unique identifier of the entity to update
   * @param updateDto - The partial update data
   * @returns A promise that resolves to the updated entity or null if not found
   */
  abstract update(id: string, updateDto: any): Promise<T | null>;

  /**
   * Updates multiple entities matching the filter criteria.
   * 
   * @param filter - The filter criteria to match entities for update
   * @param updateDto - The update data to apply to all matching entities
   * @returns A promise that resolves to the update operation result
   */
  abstract updateBulk(filter: any, updateDto: any): Promise<any>;

  /**
   * Permanently deletes an entity.
   * 
   * @param id - The unique identifier of the entity to delete
   * @returns A promise that resolves to the deleted entity or null if not found
   */
  abstract delete(id: string): Promise<T | null>;

  /**
   * Permanently deletes multiple entities matching the filter criteria.
   * 
   * @param filter - The filter criteria to match entities for deletion
   * @returns A promise that resolves to the deletion operation result
   */
  abstract deleteBulk(filter: any): Promise<any>;

  /**
   * Soft deletes an entity by marking it as deleted without removing it from the database.
   * 
   * @param id - The unique identifier of the entity to soft delete
   * @returns A promise that resolves to the soft-deleted entity or null if not found
   */
  abstract softDelete(id: string): Promise<T | null>;

  /**
   * Soft deletes multiple entities matching the filter criteria.
   * 
   * @param filter - The filter criteria to match entities for soft deletion
   * @returns A promise that resolves to the soft deletion operation result
   */
  abstract softDeleteBulk(filter: any): Promise<any>;

  /**
   * Restores a previously soft-deleted entity.
   * 
   * @param id - The unique identifier of the entity to restore
   * @returns A promise that resolves to the restored entity or null if not found
   */
  abstract restore(id: string): Promise<T | null>;

  /**
   * Restores multiple previously soft-deleted entities matching the filter criteria.
   * 
   * @param filter - The filter criteria to match entities for restoration
   * @returns A promise that resolves to the restoration operation result
   */
  abstract restoreBulk(filter: any): Promise<any>;
}
