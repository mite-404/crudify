/**
 * Union type of all available CRUD method names in the API Core framework.
 * 
 * These method names correspond to the operations defined in ApiCoreService
 * and can be used for route configuration, exclusion, or customization.
 */
export type Methods =
  | 'create'
  | 'createBulk'
  | 'findAll'
  | 'findOne'
  | 'put'
  | 'update'
  | 'updateBulk'
  | 'delete'
  | 'deleteSoft'
  | 'deleteBulk'
  | 'restore'
  | 'restoreBulk'
  | 'count';
