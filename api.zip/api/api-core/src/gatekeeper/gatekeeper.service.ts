import { Injectable, OnModuleInit } from '@nestjs/common';

/**
 * Abstract service responsible for managing the Gatekeeper logic.
 * This service implements a cache-first strategy to determine if specific
 * API routes or features are enabled for various models.
 * * It implements `OnModuleInit` to ensure configurations are loaded 
 * into memory during application startup.
 * * @abstract
 * @implements {OnModuleInit}
 */
@Injectable()
export abstract class GatekeeperService implements OnModuleInit {
  /**
   * In-memory cache holding the configuration for all registered models.
   * @protected
   * @type {Record<string, any>}
   */
  configCache: Record<string, any> = {};

  /**
   * Lifecycle hook that triggers the initial configuration load 
   * when the module is initialized.
   * @returns {Promise<void>}
   */
  async onModuleInit() {
    await this.load();
  }

  /**
   * Abstract method to load configurations from a persistent data source 
   * (e.g., MongoDB, SQL, or a Remote Config) into the local `configCache`.
   * @abstract
   * @returns {Promise<void>}
   */
  abstract load(): Promise<void>;

  /**
   * Abstract method to update the configuration for a specific model 
   * in the persistent storage.
   * @abstract
   * @param {string} model - The unique name of the model/entity.
   * @param {Partial<any>} updates - The configuration subset to apply.
   * @returns {Promise<void>}
   */
  abstract updateConfig(model: string, updates: Partial<any>): Promise<void>;

  /**
   * Checks if a specific route is enabled for a given model.
   * Defaults to `true` if the model or the route configuration is missing.
   * * @param {string} model - The name of the model/entity to check.
   * @param {string} route - The specific route or action name (e.g., 'create', 'delete').
   * @returns {boolean} True if the route is enabled, false otherwise.
   */
  isRouteEnabled(model: string, route: string): boolean {
    const modelCfg = this.configCache[model];
    if (!modelCfg) return true;
    return modelCfg.routes?.[route] ?? true;
  }

  /**
   * Retrieves the entire current configuration cache.
   * @returns {Record<string, any>} The full dictionary of model configurations.
   */
  getAll(): Record<string, any> {
    return this.configCache;
  }

  /**
   * Generates a standardized error response when a route is accessed but disabled.
   * * @param {string} modelName - The name of the model.
   * @param {string} route - The name of the disabled route.
   * @returns {Object} A standardized failure object with status 403.
   */
  notEnabledResponse(modelName: string, route: string) {
    return {
      success: false,
      status: 403,
      message: `The route '${route}' for model '${modelName}' is currently disabled.`,
    };
  }
}