import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Put,
} from '@nestjs/common';
import {
  ApiBody,
  ApiOperation,
  ApiParam,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { GatekeeperService } from './gatekeeper.service';

/**
 * Abstract controller for managing the Gatekeeper configuration.
 * Provides endpoints to retrieve, update, and manually reload the configuration cache
 * that controls route enabling/disabling and module-specific properties.
 * * @abstract
 */
@ApiTags('Config')
@Controller('config')
export abstract class GatekeeperController {
  /**
   * Creates an instance of GatekeeperController.
   * * @param configService The Gatekeeper service instance (typically injected via abstract token).
   */
  constructor(
    protected readonly configService: GatekeeperService
  ) { }

  /**
   * Retrieves the current configuration cache from memory.
   * * @returns {Object} The cached configuration for all models and their associated route flags.
   */
  @Get()
  @ApiOperation({
    summary: 'Get the current configuration cache',
    description:
      'Returns the cached configuration of all models and their enabled routes.',
  })
  @ApiResponse({
    status: 200,
    description: 'Configuration cache retrieved successfully.',
    schema: {
      example: {
        User: {
          enabled: true,
          routes: { create: true, update: false, delete: true },
          props: { otherProp: 'value' },
        },
      },
    },
  })
  getAll() {
    return this.configService?.getAll();
  }

  /**
   * Updates the configuration settings for a specific model.
   * This method persists changes and automatically triggers a cache reload.
   * * @param {string} model - The name of the model/entity to update (e.g., 'User').
   * @param {Partial<any>} updates - The configuration subset to apply (route flags or properties).
   * @returns {Promise<Object>} A confirmation object containing the updated model data.
   */
  @Put(':model')
  @ApiOperation({
    summary: 'Update configuration for a specific model',
    description:
      'Updates enabled status or specific route flags for the given model. Automatically creates the record if it does not exist.',
  })
  @ApiParam({
    name: 'model',
    description: 'Model name ',
    example: 'User',
  })
  @ApiBody({
    description: 'Partial configuration object for the given model.',
    schema: {
      example: {
        enabled: true,
        routes: {
          create: true,
          createBulk: true,
          findAll: true,
          findOne: true,
          put: true,
          update: true,
          updateBulk: true,
          delete: true,
          deleteSoft: true,
          deleteBulk: true,
          restore: true,
          restoreBulk: true,
          count: true,
        },

        props: { otherProp: 'value' },
      },
    },
  })
  @ApiResponse({
    status: 200,
    description: 'Configuration updated successfully.',
  })
  async updateConfig(
    @Param('model') model: string,
    @Body() updates: Partial<any>
  ) {
    await this.configService?.updateConfig(model, updates);
    await this.configService?.load();
    return { success: true, model, updates };
  }

  /**
   * Forces the Gatekeeper to reload all configurations from the database into the memory cache.
   * Use this to synchronize nodes or apply external database changes manually.
   * * @returns {Promise<Object>} Success status and confirmation message.
   */
  @Post('reload')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Reload configuration cache',
    description:
      'Forces a reload of the configuration cache from the database.',
  })
  @ApiResponse({
    status: 200,
    description: 'Configuration cache reloaded successfully.',
  })
  async reload() {
    await this.configService?.load();
    return { success: true, message: 'Configuration cache reloaded.' };
  }
}